import { Button } from "@/components/ui/button";
import { MessageCircle } from "lucide-react";

interface WhatsAppButtonProps {
    phoneNumber?: string;
    message?: string;
    label?: string;
    className?: string;
    variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
    size?: "default" | "sm" | "lg" | "icon";
}

export function WhatsAppButton({
    phoneNumber = "+212605260604",
    message = "Hallo, ich interessiere mich für Ihr Angebot.",
    label = "Per WhatsApp bestellen",
    className,
    variant = "default",
    size = "default"
}: WhatsAppButtonProps) {
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${phoneNumber.replace(/[^0-9]/g, "")}?text=${encodedMessage}`;

    return (
        <Button
            asChild
            variant={variant}
            size={size}
            className={`bg-[#25D366] hover:bg-[#128C7E] text-white ${className}`}
        >
            <a href={whatsappUrl} target="_blank" rel="noopener noreferrer">
                <MessageCircle className="mr-2 h-4 w-4" />
                {label}
            </a>
        </Button>
    );
}
