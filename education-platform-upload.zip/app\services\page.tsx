import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, FileText, Users, MoveRight } from "lucide-react";
import { WhatsAppButton } from "@/components/ui/whatsapp-button";
import { FadeIn } from "@/components/ui/fade-in";
import Link from "next/link";

export default function ServicesPage() {
    return (
        <div className="flex-1">
            <div className="relative bg-muted/30 py-12 md:py-24 overflow-hidden">
                <div className="absolute inset-0 bg-grid-black/[0.02] -z-10" />
                <div className="container px-4 md:px-6">
                    <FadeIn direction="down" className="flex flex-col items-center gap-4 text-center mb-16">
                        <div className="inline-block rounded-full bg-primary/10 px-3 py-1 text-sm text-primary font-medium mb-2">
                            Individuelle Beratung
                        </div>
                        <h1 className="text-3xl font-bold sm:text-4xl md:text-5xl">Unsere Dienstleistungen</h1>
                        <p className="max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                            Professionelle Unterstützung für deinen beruflichen Erfolg in Deutschland.
                        </p>
                    </FadeIn>

                    <div className="grid gap-8 md:grid-cols-2 lg:gap-12 max-w-5xl mx-auto">
                        <FadeIn delay={0.2} direction="left" className="h-full">
                            <Card className="flex flex-col h-full border-primary/10 shadow-lg hover:shadow-2xl hover:-translate-y-1 transition-all duration-300">
                                <CardHeader>
                                    <div className="flex items-center gap-3 mb-2">
                                        <div className="p-3 rounded-xl bg-blue-50 text-blue-600">
                                            <FileText className="h-8 w-8" />
                                        </div>
                                        <CardTitle className="text-2xl">Bewerbungsunterlagen</CardTitle>
                                    </div>
                                    <CardDescription className="text-base">
                                        Professionell & individuell erstellte Unterlagen als PDF in 1–2 Tagen.
                                    </CardDescription>
                                </CardHeader>
                                <CardContent className="flex-1 grid gap-4">
                                    <div className="bg-muted/50 p-4 rounded-lg">
                                        <ul className="grid gap-3 text-sm">
                                            <li className="flex items-center justify-between border-b border-border/50 pb-2">
                                                <span className="font-medium text-muted-foreground">Lebenslauf</span>
                                                <span className="font-bold">150 DH</span>
                                            </li>
                                            <li className="flex items-center justify-between border-b border-border/50 pb-2">
                                                <span className="font-medium text-muted-foreground">Anschreiben</span>
                                                <span className="font-bold">150 DH</span>
                                            </li>
                                            <li className="flex items-center justify-between pt-1">
                                                <span className="font-bold text-primary">Kombi-Paket (Beides)</span>
                                                <span className="font-bold text-xl text-primary">200 DH</span>
                                            </li>
                                        </ul>
                                    </div>
                                    <ul className="grid gap-2 text-sm text-muted-foreground mt-2">
                                        <li className="flex items-center gap-2">
                                            <Check className="h-4 w-4 text-green-500" /> Auf Deutsch verfasst
                                        </li>
                                        <li className="flex items-center gap-2">
                                            <Check className="h-4 w-4 text-green-500" /> PDF-Format (Druckbereit)
                                        </li>
                                    </ul>
                                </CardContent>
                                <CardFooter>
                                    <WhatsAppButton
                                        className="w-full text-lg shadow-md"
                                        label="Jetzt bestellen"
                                        message="Hallo, ich brauche Hilfe bei meinen Bewerbungsunterlagen."
                                    />
                                </CardFooter>
                            </Card>
                        </FadeIn>

                        <FadeIn delay={0.4} direction="right" className="h-full">
                            <Card className="flex flex-col h-full border-primary/10 shadow-lg hover:shadow-2xl hover:-translate-y-1 transition-all duration-300">
                                <CardHeader>
                                    <div className="flex items-center gap-3 mb-2">
                                        <div className="p-3 rounded-xl bg-purple-50 text-purple-600">
                                            <Users className="h-8 w-8" />
                                        </div>
                                        <CardTitle className="text-2xl">Interview Coaching</CardTitle>
                                    </div>
                                    <CardDescription className="text-base">
                                        Spezielle Vorbereitung auf Vorstellungsgespräche im Pflegebereich.
                                    </CardDescription>
                                </CardHeader>
                                <CardContent className="flex-1 grid gap-4">
                                    <div className="mb-2 p-4 bg-purple-50/50 rounded-lg flex items-center justify-between">
                                        <span className="text-muted-foreground font-medium">Komplettpaket</span>
                                        <span className="text-3xl font-bold text-purple-600">300 DH</span>
                                    </div>
                                    <ul className="grid gap-3 text-sm">
                                        <li className="flex items-center gap-3">
                                            <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                                            <span>3 intensive Einheiten (je 2 Stunden)</span>
                                        </li>
                                        <li className="flex items-center gap-3">
                                            <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                                            <span>Typische Fragen & Antworten üben</span>
                                        </li>
                                        <li className="flex items-center gap-3">
                                            <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                                            <span>Ablauf von Pflege-Interviews verstehen</span>
                                        </li>
                                        <li className="flex items-center gap-3 font-semibold text-primary">
                                            <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                                            <span>+ E-Book Bonus inklusive!</span>
                                        </li>
                                    </ul>
                                </CardContent>
                                <CardFooter>
                                    <WhatsAppButton
                                        className="w-full text-lg shadow-md"
                                        label="Termin vereinbaren"
                                        message="Hallo, ich interessiere mich für das Interview-Coaching."
                                    />
                                </CardFooter>
                            </Card>
                        </FadeIn>
                    </div>
                </div>
            </div>

            <div className="container py-12 md:py-24">
                <FadeIn direction="up">
                    <div className="p-8 md:p-12 bg-gradient-to-br from-gray-900 to-gray-800 rounded-3xl text-center shadow-2xl skew-y-1">
                        <div className="-skew-y-1">
                            <h2 className="text-2xl md:text-3xl font-bold mb-4 text-white">Noch unsicher?</h2>
                            <p className="mb-8 text-gray-300 max-w-2xl mx-auto text-lg">
                                Jede Karriere ist einzigartig. Schreib uns einfach eine Nachricht und wir schauen gemeinsam, wie wir dir am besten helfen können.
                            </p>
                            <WhatsAppButton
                                variant="outline"
                                size="lg"
                                label="Kostenloses Erstgespräch"
                                message="Hallo, ich habe eine Frage zu euren Dienstleistungen."
                                className="bg-transparent text-white border-white hover:bg-white hover:text-gray-900 transition-colors text-lg px-8"
                            />
                        </div>
                    </div>
                </FadeIn>
            </div>
        </div>
    );
}
