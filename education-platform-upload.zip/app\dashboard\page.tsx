import { auth, currentUser } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { PlayCircle, Award, FileText } from "lucide-react";

export default async function DashboardPage() {
    const { userId } = await auth();

    if (!userId) {
        redirect("/sign-in");
    }

    const user = await currentUser();

    return (
        <div className="container py-12 md:py-24">
            <h1 className="text-3xl font-bold mb-8">
                Willkommen zurück, {user?.firstName || "Schüler"}! 👋
            </h1>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {/* My Courses Section */}
                <Card className="col-span-full md:col-span-2">
                    <CardHeader>
                        <CardTitle>Meine Kurse</CardTitle>
                        <CardDescription>Hier findest du deine gekauften Inhalte.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        {/* Demo Content - In a real app, this would check DB purchases */}
                        <div className="bg-muted p-8 text-center rounded-lg border-2 border-dashed">
                            <PlayCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                            <h3 className="text-xl font-semibold mb-2">Noch keine Kurse aktiviert</h3>
                            <p className="text-muted-foreground mb-6">
                                Du hast noch keinen Zugriff auf Video-Kurse. Wenn du bereits bezahlt hast,
                                kontaktiere uns bitte per WhatsApp zur Freischaltung.
                            </p>
                            <Button asChild>
                                <Link href="/videos">Kurs kaufen</Link>
                            </Button>
                        </div>
                    </CardContent>
                </Card>

                {/* Quick Actions */}
                <Card>
                    <CardHeader>
                        <CardTitle>Schnellzugriff</CardTitle>
                    </CardHeader>
                    <CardContent className="grid gap-4">
                        <Button variant="outline" className="w-full justify-start gap-2" asChild>
                            <Link href="/services">
                                <FileText className="h-4 w-4" /> CV Check
                            </Link>
                        </Button>
                        <Button variant="outline" className="w-full justify-start gap-2" asChild>
                            <Link href="/courses">
                                <Award className="h-4 w-4" /> Zertifikatskurse
                            </Link>
                        </Button>
                        <Button variant="ghost" className="w-full justify-start text-muted-foreground">
                            Profil bearbeiten (Coming Soon)
                        </Button>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
