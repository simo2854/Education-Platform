export default function Impressum() {
    return (
        <div className="container py-12 md:py-24 max-w-3xl">
            <h1 className="text-3xl font-bold mb-8">Impressum</h1>

            <div className="prose dark:prose-invert">
                <h2 className="text-xl font-bold mt-6 mb-4">Angaben gemäß § 5 TMG</h2>
                <p>
                    [Dein Name / Firmenname]<br />
                    [Straße und Hausnummer]<br />
                    [PLZ und Ort]
                </p>

                <h2 className="text-xl font-bold mt-6 mb-4">Kontakt</h2>
                <p>
                    Telefon: [Deine Telefonnummer]<br />
                    E-Mail: [Deine E-Mail-Adresse]
                </p>

                <h2 className="text-xl font-bold mt-6 mb-4">EU-Streitschlichtung</h2>
                <p>
                    Die Europäische Kommission stellt eine Plattform zur Online-Streitbeilegung (OS) bereit:
                    <a href="https://ec.europa.eu/consumers/odr/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                        https://ec.europa.eu/consumers/odr/
                    </a>.<br />
                    Unsere E-Mail-Adresse finden Sie oben im Impressum.
                </p>

                <h2 className="text-xl font-bold mt-6 mb-4">Verbraucherstreitbeilegung/Universalschlichtungsstelle</h2>
                <p>
                    Wir sind nicht bereit oder verpflichtet, an Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle teilzunehmen.
                </p>
            </div>
        </div>
    )
}
