import Link from "next/link";
import { MoveRight, PlayCircle, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { WhatsAppButton } from "@/components/ui/whatsapp-button";
import { FadeIn } from "@/components/ui/fade-in";

export default function Home() {
    return (
        <main className="flex-1 overflow-hidden">
            <section className="relative w-full py-20 md:py-32 lg:py-48 bg-gradient-to-b from-background to-primary/5">
                {/* Decorative background elements */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-primary/10 rounded-full blur-3xl -z-10 opacity-50 pointer-events-none" />

                <div className="container px-4 md:px-6 relative z-10">
                    <div className="flex flex-col items-center space-y-4 text-center">
                        <FadeIn delay={0.1} direction="down">
                            <div className="inline-block rounded-full bg-primary/10 px-3 py-1 text-sm text-primary font-medium mb-4">
                                🚀 Deine Zukunft startet hier
                            </div>
                        </FadeIn>

                        <FadeIn delay={0.2}>
                            <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl md:text-6xl lg:text-7xl">
                                Deutsch lernen & <span className="text-primary bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-600">Karriere machen</span>
                            </h1>
                        </FadeIn>

                        <FadeIn delay={0.3} className="max-w-[800px]">
                            <p className="mx-auto text-gray-500 md:text-xl dark:text-gray-400 leading-relaxed">
                                Dein Weg zum Erfolg in Deutschland. Wir helfen dir bei professionellen Deutschkursen, perfekten Bewerbungsunterlagen und der erfolgreichen Ausbildungssuche.
                            </p>
                        </FadeIn>

                        <FadeIn delay={0.4} className="flex flex-wrap justify-center gap-4 mt-8">
                            <Button asChild size="lg" className="h-12 px-8 text-lg shadow-xl shadow-primary/20 hover:shadow-primary/40 transition-all hover:-translate-y-1">
                                <Link href="/courses">Jetzt Kurse entdecken</Link>
                            </Button>
                            <Button asChild variant="outline" size="lg" className="h-12 px-8 text-lg hover:bg-muted/50 transition-all hover:-translate-y-1">
                                <Link href="/services">Zu den Dienstleistungen</Link>
                            </Button>
                        </FadeIn>
                    </div>
                </div>
            </section>

            {/* Featured Course Section */}
            <section className="w-full py-20 md:py-32 bg-background relative">
                <div className="container px-4 md:px-6">
                    <div className="grid lg:grid-cols-2 gap-16 items-center">
                        <FadeIn direction="left" className="flex flex-col space-y-6">
                            <div className="inline-block rounded-lg bg-orange-100 dark:bg-orange-900/30 px-3 py-1 text-sm text-orange-600 dark:text-orange-400 font-bold w-fit">
                                🔥 Neu & Beliebt
                            </div>
                            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                                B2 Komplettpaket - <br />Aufgezeichneter Kurs
                            </h2>
                            <p className="text-gray-500 md:text-lg dark:text-gray-400">
                                Lerne flexibel wann und wo du willst. Unser B2 Komplettpaket bereitet dich optimal auf den Beruf vor.
                            </p>
                            <ul className="grid gap-3 text-gray-500 dark:text-gray-400">
                                <li className="flex items-center gap-3">
                                    <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-primary">
                                        <Check className="h-4 w-4" />
                                    </div>
                                    <span className="font-medium">11 intensive Lerneinheiten</span>
                                </li>
                                <li className="flex items-center gap-3">
                                    <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-primary">
                                        <Check className="h-4 w-4" />
                                    </div>
                                    <span className="font-medium">Erklärungen auf Deutsch & Darija</span>
                                </li>
                                <li className="flex items-center gap-3">
                                    <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-primary">
                                        <Check className="h-4 w-4" />
                                    </div>
                                    <span className="font-medium">Lebenslanger Zugriff für nur <span className="text-primary font-bold">300 DH</span></span>
                                </li>
                            </ul>
                            <div className="flex flex-col sm:flex-row gap-4 pt-4">
                                <WhatsAppButton
                                    className="w-fit shadow-lg hover:shadow-xl transition-all hover:scale-105"
                                    label="Jetzt für 300 DH kaufen"
                                    message="Hallo, ich möchte das B2 Video-Komplettpaket kaufen."
                                />
                                <Button asChild variant="ghost" className="w-fit hover:bg-transparent hover:text-primary group">
                                    <Link href="/videos" className="flex items-center gap-2">
                                        Mehr erfahren <MoveRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                                    </Link>
                                </Button>
                            </div>
                        </FadeIn>

                        <FadeIn direction="right" delay={0.2} className="relative group">
                            <div className="absolute inset-0 bg-primary blur-3xl opacity-20 group-hover:opacity-30 transition-opacity rounded-full z-0" />
                            <div className="relative aspect-video rounded-2xl overflow-hidden shadow-2xl border-4 border-background z-10 transform transition-transform group-hover:scale-[1.02] duration-500">
                                <div className="absolute inset-0 bg-gray-900/20 z-10 transition-colors group-hover:bg-gray-900/10" />
                                <div className="absolute inset-0 flex items-center justify-center z-20">
                                    <Link href="/videos" className="group/play">
                                        <PlayCircle className="h-24 w-24 text-white opacity-90 transition-all group-hover/play:scale-110 drop-shadow-2xl" />
                                    </Link>
                                </div>
                                <div className="h-full w-full bg-gradient-to-br from-gray-100 to-gray-300 flex items-center justify-center text-muted-foreground font-bold text-2xl">
                                    {/* Placeholder for real image */}
                                    Kurs Vorschau
                                </div>
                            </div>
                            {/* Floating badges */}
                            <div className="absolute -bottom-6 -left-6 bg-background p-4 rounded-xl shadow-xl border border-border z-20 animate-bounce delay-700 duration-[3000ms]">
                                <div className="text-sm font-bold text-gray-500">Preis</div>
                                <div className="text-2xl font-bold text-primary">300 DH</div>
                            </div>
                        </FadeIn>
                    </div>
                </div>
            </section>

            <section className="w-full py-20 md:py-32 bg-gray-50 dark:bg-gray-900/50">
                <div className="container px-4 md:px-6">
                    <FadeIn direction="up" className="text-center mb-16">
                        <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-4">Was wir bieten</h2>
                        <p className="max-w-[600px] mx-auto text-gray-500 md:text-xl">Alles was du brauchst, um in Deutschland erfolgreich zu starten.</p>
                    </FadeIn>

                    <div className="grid gap-8 lg:grid-cols-3">
                        {[
                            {
                                title: "Live Sprachkurse",
                                desc: "Interaktiver Unterricht via Zoom in kleinen Gruppen. B1 & B2 Level.",
                                link: "/courses",
                                linkText: "Details ansehen",
                                icon: (
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-8 w-8">
                                        <path d="M22 10v6M2 10v6M2 10C2 4.477 6.477 0 12 0s10 4.477 10 10-6.477 10-10 10S2 15.523 2 10z"></path>
                                        <path d="M12 4v4"></path>
                                        <path d="M7 10h10"></path>
                                        <path d="M7 14h10"></path>
                                    </svg>
                                )
                            },
                            {
                                title: "Bewerbungshilfe",
                                desc: "Professionelle CVs und Anschreiben. Erhöhe deine Chancen auf den Job.",
                                link: "/services",
                                linkText: "Mehr erfahren",
                                icon: (
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-8 w-8">
                                        <rect width="20" height="14" x="2" y="3" rx="2"></rect>
                                        <line x1="8" x2="16" y1="21" y2="21"></line>
                                        <line x1="12" x2="12" y1="17" y2="21"></line>
                                    </svg>
                                )
                            },
                            {
                                title: "Ausbildungsplatz",
                                desc: "Persönliche Beratung und Vermittlung in deutsche Ausbildungen.",
                                link: "/services",
                                linkText: "Beratung buchen",
                                icon: (
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-8 w-8">
                                        <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"></path>
                                    </svg>
                                )
                            }
                        ].map((item, index) => (
                            <FadeIn key={index} delay={index * 0.1} className="flex flex-col items-center space-y-4 text-center p-8 rounded-2xl bg-background border border-border/50 shadow-sm hover:shadow-xl hover:-translate-y-2 transition-all duration-300">
                                <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-primary mb-2">
                                    {item.icon}
                                </div>
                                <h3 className="text-xl font-bold">{item.title}</h3>
                                <p className="text-gray-500 dark:text-gray-400">
                                    {item.desc}
                                </p>
                                <Button asChild variant="link" className="text-primary font-semibold hover:text-primary/80">
                                    <Link href={item.link}>{item.linkText}</Link>
                                </Button>
                            </FadeIn>
                        ))}
                    </div>
                </div>
            </section>
        </main>
    );
}
