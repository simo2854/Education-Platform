import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Calendar, Clock, GraduationCap, Video, Check, Users } from "lucide-react";
import { WhatsAppButton } from "@/components/ui/whatsapp-button";
import { FadeIn } from "@/components/ui/fade-in";

export default function CoursesPage() {
    const courses = [
        {
            title: "B1 TELC Prüfungsvorbereitung",
            level: "B1",
            description: "Intensivkurs zur Vorbereitung auf die B1 Prüfung (TELC/Goethe). Fokus auf Prüfungsstrategien.",
            price: "Auf Anfrage",
            duration: "2-4 Wochen",
            schedule: "Live Online",
            features: ["Prüfungssimulation", "Mündliches Training", "Korrektur schriftlicher Aufgaben"],
            icon: BookOpen,
            highlight: "Prüfungskurs"
        },
        {
            title: "B2 TELC Prüfungsvorbereitung",
            level: "B2",
            description: "Spezialkurs für die B2 TELC Prüfung. Wir machen dich fit für den Abschluss.",
            price: "500 DH",
            duration: "1 Monat",
            schedule: "Live Online",
            features: ["Erklärung auf Deutsch & Darija", "Fokus auf 'Sprechen'", "Schreibtraining"],
            icon: GraduationCap,
            highlight: "Beliebt"
        },
        {
            title: "B1 Niveau Komplett",
            level: "B1",
            description: "Der gesamte B1 Kurs live mit Lehrer. Von A2 kommend bis zur Prüfungsreife.",
            price: "Auf Anfrage",
            duration: "2-3 Monate",
            schedule: "Live Online",
            features: ["Interaktiver Unterricht", "Kleine Gruppen", "Start auf Anfrage"],
            icon: Users,
            highlight: "Live-Kurs"
        },
        {
            title: "B2 Niveau Komplett",
            level: "B2",
            description: "Der gesamte B2 Kurs für Fortgeschrittene und Beruf.",
            price: "Auf Anfrage",
            duration: "2-3 Monate",
            schedule: "Live Online",
            features: ["Berufsbezogenes Deutsch", "Intensive Grammatik", "Start auf Anfrage"],
            icon: Users,
            highlight: "Live-Kurs"
        },
    ];

    return (
        <div className="container py-12 md:py-24">
            <div className="flex flex-col items-center gap-4 text-center mb-16">
                <FadeIn direction="down">
                    <h1 className="text-3xl font-bold sm:text-4xl md:text-5xl mb-4">Unsere Sprachkurse</h1>
                </FadeIn>
                <FadeIn delay={0.2} direction="up">
                    <p className="max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                        Wähle das passende Format für dich: Live-Unterricht, flexible Videokurse oder gezielte Prüfungsvorbereitung.
                    </p>
                </FadeIn>
            </div>

            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 lg:max-w-7xl lg:mx-auto">
                {courses.map((course, index) => {
                    const Icon = course.icon;
                    return (
                        <FadeIn key={index} delay={index * 0.1} className="h-full">
                            <Card className="flex flex-col h-full border-primary/20 shadow-lg hover:shadow-2xl transition-all duration-300 relative overflow-hidden group">
                                {course.highlight && (
                                    <div className="absolute top-0 right-0 bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-bl-lg z-10 shadow-sm">
                                        {course.highlight}
                                    </div>
                                )}
                                <CardHeader className="relative">
                                    <div className="absolute top-4 right-4 text-primary/10 -rotate-12 transition-transform group-hover:rotate-0 duration-500">
                                        <Icon className="h-24 w-24" />
                                    </div>
                                    <div className="flex justify-between items-start mb-2 relative z-10">
                                        <Badge variant="outline" className="mb-2 bg-background/50 backdrop-blur">
                                            {course.level}
                                        </Badge>
                                    </div>
                                    <CardTitle className="text-2xl relative z-10">{course.title}</CardTitle>
                                    <CardDescription className="relative z-10">{course.description}</CardDescription>
                                </CardHeader>
                                <CardContent className="flex-1 grid gap-4 relative z-10">
                                    <div className="flex items-center justify-between border-b pb-4">
                                        <div className="font-bold text-2xl text-primary">{course.price}</div>
                                        <div className="text-sm text-muted-foreground flex flex-col items-end">
                                            <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {course.duration}</span>
                                            <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {course.schedule}</span>
                                        </div>
                                    </div>
                                    <ul className="text-sm space-y-3 mt-2">
                                        {course.features.map((feature, i) => (
                                            <li key={i} className="flex items-center gap-2">
                                                <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                                                    <Check className="h-3 w-3" />
                                                </div>
                                                {feature}
                                            </li>
                                        ))}
                                    </ul>
                                </CardContent>
                                <CardFooter className="relative z-10">
                                    <WhatsAppButton
                                        className="w-full text-lg shadow-md group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
                                        label="Jetzt anmelden"
                                        message={`Hallo, ich interessiere mich für den Kurs: ${course.title}.`}
                                    />
                                </CardFooter>
                            </Card>
                        </FadeIn>
                    );
                })}
            </div>

            <FadeIn delay={0.6} className="mt-16 text-center">
                <p className="text-muted-foreground bg-muted/50 inline-block px-4 py-2 rounded-full text-sm">
                    * Alle Videokurse sind sofort verfügbar. Live-Kurse starten monatlich.
                </p>
            </FadeIn>
        </div>
    );
}
