import { WhatsAppButton } from "@/components/ui/whatsapp-button";
import { Mail, MapPin, Phone } from "lucide-react";

export default function KontaktPage() {
    return (
        <div className="container py-12 md:py-24">
            <div className="flex flex-col items-center gap-4 text-center mb-16">
                <h1 className="text-3xl font-bold sm:text-4xl md:text-5xl">Kontakt</h1>
                <p className="max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                    Wir sind für dich da. Schreib uns einfach.
                </p>
            </div>

            <div className="grid md:grid-cols-2 gap-12 max-w-4xl mx-auto items-center">
                <div className="space-y-8">
                    <div className="flex items-center gap-4">
                        <div className="bg-primary/10 p-3 rounded-full">
                            <Phone className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                            <h3 className="font-semibold text-lg">WhatsApp & Telefon</h3>
                            <p className="text-muted-foreground">+212 605 260 604</p>
                        </div>
                    </div>

                    <div className="flex items-center gap-4">
                        <div className="bg-primary/10 p-3 rounded-full">
                            <Mail className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                            <h3 className="font-semibold text-lg">E-Mail</h3>
                            <p className="text-muted-foreground">info@deutsch-lernen.com</p>
                        </div>
                    </div>

                    <div className="flex items-center gap-4">
                        <div className="bg-primary/10 p-3 rounded-full">
                            <MapPin className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                            <h3 className="font-semibold text-lg">Standort</h3>
                            <p className="text-muted-foreground">Online & Weltweit</p>
                        </div>
                    </div>
                </div>

                <div className="bg-muted p-8 rounded-2xl text-center shadow-lg">
                    <h3 className="text-2xl font-bold mb-4">Direkt Chatten?</h3>
                    <p className="text-muted-foreground mb-6">
                        Der schnellste Weg zu uns ist über WhatsApp. Wir antworten in der Regel innerhalb weniger Stunden.
                    </p>
                    <WhatsAppButton
                        size="lg"
                        className="w-full text-lg py-6"
                        message="Hallo, ich habe eine allgemeine Anfrage."
                        label="WhatsApp Chat starten"
                    />
                </div>
            </div>
        </div>
    );
}
