export default function Datenschutz() {
    return (
        <div className="container py-12 md:py-24 max-w-3xl">
            <h1 className="text-3xl font-bold mb-8">Datenschutzerklärung</h1>

            <div className="prose dark:prose-invert">
                <h2 className="text-xl font-bold mt-6 mb-4">1. Datenschutz auf einen Blick</h2>
                <h3 className="text-lg font-bold mt-4 mb-2">Allgemeine Hinweise</h3>
                <p>
                    Die folgenden Hinweise geben einen einfachen Überblick darüber, was mit Ihren personenbezogenen Daten passiert, wenn Sie diese Website besuchen.
                </p>

                <h2 className="text-xl font-bold mt-6 mb-4">2. Hosting</h2>
                <p>
                    Wir hosten die Inhalte unserer Website bei folgendem Anbieter: [Anbieter-Name].
                </p>

                <h2 className="text-xl font-bold mt-6 mb-4">3. Allgemeine Hinweise und Pflichtinformationen</h2>
                <h3 className="text-lg font-bold mt-4 mb-2">Datenschutz</h3>
                <p>
                    Die Betreiber dieser Seiten nehmen den Schutz Ihrer persönlichen Daten sehr ernst. Wir behandeln Ihre personenbezogenen Daten vertraulich und entsprechend den gesetzlichen Datenschutzvorschriften sowie dieser Datenschutzerklärung.
                </p>

                <h3 className="text-lg font-bold mt-4 mb-2">Hinweis zur verantwortlichen Stelle</h3>
                <p>
                    Die verantwortliche Stelle für die Datenverarbeitung auf dieser Website ist:<br />
                    [Dein Name / Firmenname]<br />
                    [Adresse]<br />
                    E-Mail: [E-Mail-Adresse]
                </p>
            </div>
        </div>
    )
}
