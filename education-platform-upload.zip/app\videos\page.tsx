import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PlayCircle, Lock, CheckCircle, Smartphone, FolderOpen, BookOpen } from "lucide-react";
import { WhatsAppButton } from "@/components/ui/whatsapp-button";
import { FadeIn } from "@/components/ui/fade-in";

export default function VideosPage() {
    const b1Curriculum = [
        "Einführung B1 & Wiederholung A2",
        "Vergangenheit & Zukunft (Zeitformen)",
        "Nebensätze & Konjunktionen",
        "Adjektivdeklination",
        "Präpositionen (Ort & Zeit)",
        "Passiv & Alternativen",
        "Konjunktiv II (Wünsche & Höflichkeit)",
        "Wortschatz: Arbeit & Beruf",
        "Wortschatz: Gesundheit & Umwelt",
        "Briefe schreiben (Prüfungstraining)",
        "Mündliche Prüfung B1 Simulation"
    ];

    const b2Curriculum = [
        "Einführung in B2 & Lernstrategien",
        "Verben mit festen Präpositionen",
        "Nomen-Verb-Verbindungen",
        "Passiv & Passiversatzformen",
        "Konjunktiv I & II (Indirekte Rede)",
        "Subjektive Bedeutung der Modalverben",
        "Satzverbindungen & Textgliederung",
        "Wortschatz: Medizin & Pflege",
        "Grafikbeschreibung (Schreiben)",
        "Diskussion & Vortrag (Sprechen)",
        "Prüfungssimulation TELC B2"
    ];

    return (
        <div className="container py-12 md:py-24">
            <div className="flex flex-col items-center gap-4 text-center mb-16">
                <FadeIn direction="down">
                    <Badge className="mb-4 bg-red-100 text-red-600 hover:bg-red-100 border-none text-md px-3 py-1">
                        🔴 Bestseller
                    </Badge>
                    <h1 className="text-3xl font-bold sm:text-4xl md:text-5xl">Aufgezeichnete Videokurse</h1>
                </FadeIn>
                <FadeIn delay={0.1} direction="up">
                    <p className="max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                        Lerne wann und wo du willst. Einmal zahlen, lebenslanger Zugriff.
                    </p>
                </FadeIn>
            </div>

            <div className="grid gap-16 lg:grid-cols-2 lg:gap-12 max-w-7xl mx-auto">
                {/* B1 Course */}
                <FadeIn direction="right" delay={0.2} className="flex flex-col h-full">
                    <div className="relative aspect-video rounded-xl overflow-hidden shadow-2xl border-4 border-background mb-8 group cursor-pointer">
                        <div className="absolute inset-0 bg-blue-900/20 z-10 transition-colors group-hover:bg-blue-900/10" />
                        <div className="absolute inset-0 flex items-center justify-center z-20">
                            <PlayCircle className="h-20 w-20 text-white opacity-90 transition-transform group-hover:scale-110 drop-shadow-lg" />
                        </div>
                        <div className="h-full w-full bg-gradient-to-br from-blue-300 to-blue-600 flex items-center justify-center text-white font-bold text-3xl">
                            B1 Komplett
                        </div>
                    </div>

                    <div className="flex-1">
                        <h2 className="text-3xl font-bold mb-2">B1 Komplettpaket</h2>
                        <p className="text-muted-foreground mb-6">Der ideale Einstieg in die Mittelstufe. Alle Grundlagen sicher beherrschen.</p>

                        <div className="flex items-center gap-4 mb-6">
                            <div className="text-4xl font-bold text-primary">300 DH</div>
                            <div className="text-sm text-muted-foreground line-through">450 DH</div>
                            <Badge variant="secondary" className="ml-auto">11 Lektionen</Badge>
                        </div>

                        <div className="bg-muted/50 rounded-xl p-6 mb-8 border border-border/50">
                            <h3 className="font-semibold mb-4 flex items-center gap-2">
                                <FolderOpen className="h-5 w-5 text-primary" /> Lehrplan
                            </h3>
                            <ul className="space-y-3">
                                {b1Curriculum.map((item, i) => (
                                    <li key={i} className="flex items-center gap-3 text-sm">
                                        {i < 2 ? (
                                            <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                                        ) : (
                                            <Lock className="h-4 w-4 text-muted-foreground/50 flex-shrink-0" />
                                        )}
                                        <span className={i >= 2 ? "text-muted-foreground" : ""}>{item}</span>
                                        {i < 2 && <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full ml-auto">Vorschau</span>}
                                    </li>
                                ))}
                            </ul>
                        </div>

                        <WhatsAppButton
                            className="w-full text-lg h-12"
                            label="B1 Kurs jetzt kaufen (300 DH)"
                            message="Hallo, ich möchte das B1 Video-Komplettpaket kaufen."
                        />
                    </div>
                </FadeIn>

                {/* B2 Course */}
                <FadeIn direction="left" delay={0.3} className="flex flex-col h-full">
                    <div className="relative aspect-video rounded-xl overflow-hidden shadow-2xl border-4 border-background mb-8 group cursor-pointer">
                        <div className="absolute inset-0 bg-primary/20 z-10 transition-colors group-hover:bg-primary/10" />
                        <div className="absolute inset-0 flex items-center justify-center z-20">
                            <PlayCircle className="h-20 w-20 text-white opacity-90 transition-transform group-hover:scale-110 drop-shadow-lg" />
                        </div>
                        <div className="h-full w-full bg-gradient-to-br from-orange-300 to-orange-600 flex items-center justify-center text-white font-bold text-3xl">
                            B2 Komplett
                        </div>
                    </div>

                    <div className="flex-1">
                        <h2 className="text-3xl font-bold mb-2">B2 Komplettpaket</h2>
                        <p className="text-muted-foreground mb-6">Perfekt für den Berufseinstieg und die Prüfungsvorbereitung.</p>

                        <div className="flex items-center gap-4 mb-6">
                            <div className="text-4xl font-bold text-primary">300 DH</div>
                            <div className="text-sm text-muted-foreground line-through">500 DH</div>
                            <Badge variant="secondary" className="ml-auto">11 Lektionen</Badge>
                        </div>

                        <div className="bg-muted/50 rounded-xl p-6 mb-8 border border-border/50">
                            <h3 className="font-semibold mb-4 flex items-center gap-2">
                                <FolderOpen className="h-5 w-5 text-primary" /> Lehrplan
                            </h3>
                            <ul className="space-y-3">
                                {b2Curriculum.map((item, i) => (
                                    <li key={i} className="flex items-center gap-3 text-sm">
                                        {i < 2 ? (
                                            <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                                        ) : (
                                            <Lock className="h-4 w-4 text-muted-foreground/50 flex-shrink-0" />
                                        )}
                                        <span className={i >= 2 ? "text-muted-foreground" : ""}>{item}</span>
                                        {i < 2 && <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full ml-auto">Vorschau</span>}
                                    </li>
                                ))}
                            </ul>
                        </div>

                        <WhatsAppButton
                            className="w-full text-lg h-12"
                            label="B2 Kurs jetzt kaufen (300 DH)"
                            message="Hallo, ich möchte das B2 Video-Komplettpaket kaufen."
                        />
                    </div>
                </FadeIn>
            </div>

            <FadeIn delay={0.5} className="mt-24 p-8 bg-muted/30 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-8 border border-border/50">
                <div className="flex items-center gap-6">
                    <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                        <Smartphone className="h-8 w-8" />
                    </div>
                    <div>
                        <h3 className="text-xl font-bold mb-2">Lerne wo du willst</h3>
                        <p className="text-muted-foreground max-w-sm">Unsere Plattform funktioniert auf dem Smartphone, Tablet und Laptop. Dein Fortschritt wird gespeichert.</p>
                    </div>
                </div>
                <div className="h-12 w-px bg-border hidden md:block" />
                <div className="text-right">
                    <div className="text-sm text-muted-foreground mb-1">Bundle Angebot</div>
                    <div className="font-bold text-lg mb-2">B1 + B2 zusammen kaufen?</div>
                    <WhatsAppButton
                        variant="outline"
                        label="Kombi-Preis anfragen"
                        message="Hallo, gibt es einen Rabatt wenn ich B1 und B2 Videokurse zusammen kaufe?"
                    />
                </div>
            </FadeIn>
        </div>
    );
}
