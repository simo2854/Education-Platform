import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Menu } from "lucide-react";
import { SignInButton, SignedIn, SignedOut, UserButton } from "@clerk/nextjs";

export function Header() {
    return (
        <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
            <div className="container flex h-14 items-center">
                <Link href="/" className="mr-6 flex items-center space-x-2">
                    <span className="hidden font-bold sm:inline-block">
                        Deutsch lernen
                    </span>
                </Link>
                <nav className="flex items-center space-x-6 text-sm font-medium">
                    <Link
                        href="/services"
                        className="transition-colors hover:text-foreground/80 text-foreground/60"
                    >
                        Dienstleistungen
                    </Link>
                    <Link
                        href="/courses"
                        className="transition-colors hover:text-foreground/80 text-foreground/60"
                    >
                        Kurse
                    </Link>
                    <Link
                        href="/videos"
                        className="transition-colors hover:text-foreground/80 text-foreground/60"
                    >
                        Videos
                    </Link>
                </nav>
                <div className="ml-auto flex items-center space-x-4">
                    <SignedOut>
                        <SignInButton mode="modal">
                            <Button size="sm" variant="ghost">Anmelden</Button>
                        </SignInButton>
                        <Button size="sm" asChild>
                            <Link href="/sign-up">Registrieren</Link>
                        </Button>
                    </SignedOut>
                    <SignedIn>
                        <Button size="sm" variant="ghost" asChild className="mr-2">
                            <Link href="/dashboard">Mein Bereich</Link>
                        </Button>
                        <UserButton afterSignOutUrl="/" />
                    </SignedIn>
                    <Button variant="ghost" size="icon" className="md:hidden">
                        <Menu className="h-5 w-5" />
                        <span className="sr-only">Menu</span>
                    </Button>
                </div>
            </div>
        </header>
    );
}
